------------------------------------------------------------------------
--[[ BIWI Dataset Loader ]] --
------------------------------------------------------------------------
require 'image'

local Biwi, DataSource = torch.class("dp.Biwi", "dp.DataSource")
Biwi.isBiwi = true

Biwi._name = 'Biwi'
--Biwi._image_size = { 56, 144, 3 }
Biwi._image_size = { 120, 160, 3 }
Biwi._image_axes = 'bhwc'
--Biwi._feature_size = 1 * 56 * 144
Biwi._feature_size = 1 * 120 * 160
Biwi._classes = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
                  28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 }

function Biwi:__init(config)
    config = config or {}
    assert(torch.type(config) == 'table' and not config[1],
        "Constructor requires key-value arguments")
    local args, load_all, input_preprocess, target_preprocess
    args, self._valid_ratio, self._train_file, self._test_file,
    self._data_path, self._scale, self._binarize, self._shuffle,
    self._download_url, load_all, input_preprocess,
    target_preprocess
    = xlua.unpack({ config },
        'Biwi',
        'Biwi reidentification problem' ..
                'Note: Train and valid sets are already shuffled.',
        {
            arg = 'valid_ratio',
            type = 'number',
            default = 0,   -- default 1/6
            help = 'proportion of training set to use for cross-validation.'
        },
        {
            arg = 'train_file',
            type = 'string',
            default = 'train.th7',
            help = 'name of training file'
        },
        {
            arg = 'test_file',
            type = 'string',
            default = 'test.th7',
            help = 'name of test file'
        },
        {
            arg = 'data_path',
            type = 'string',
            default = '../datasets/',
            help = 'path to data repository'
        },
        {
            arg = 'scale',
            type = 'table',
            help = 'bounds to scale the values between. [Default={0,1}]'
        },
        {
            arg = 'binarize',
            type = 'boolean',
            help = 'binarize the inputs (0s and 1s)',
            default = false
        },
        {
            arg = 'shuffle',
            type = 'boolean',
            help = 'shuffle different sets',
            default = false
        },
        {
            arg = 'download_url',
            type = 'string',
            default = '',
            help = 'URL from which to download dataset if not found on disk.'
        },
        {
            arg = 'load_all',
            type = 'boolean',
            help = 'Load all datasets : train, valid, test.',
            default = true
        },
        {
            arg = 'input_preprocess',
            type = 'table | dp.Preprocess',
            help = 'to be performed on set inputs, measuring statistics ' ..
                    '(fitting) on the train_set only, and reusing these to ' ..
                    'preprocess the valid_set and test_set.'
        },
        {
            arg = 'target_preprocess',
            type = 'table | dp.Preprocess',
            help = 'to be performed on set targets, measuring statistics ' ..
                    '(fitting) on the train_set only, and reusing these to ' ..
                    'preprocess the valid_set and test_set.'
        })
    if (self._scale == nil) then
        self._scale = { 0, 1 }
    end
    if load_all then
        print('Loading training data...')
        self:loadTrainValid()
        print('Loading test set data...')
        self:loadTest()
    end
    DataSource.__init(self, {
        train_set = self:trainSet(),
        valid_set = self:validSet(),
        test_set = self:testSet(),
        input_preprocess = input_preprocess,
        target_preprocess = target_preprocess
    })
end

function Biwi:loadTrainValid()
    --Data will contain a tensor where each row is an example, and where
    --the last column contains the target class.
    --local data = self:loadData(self._train_file, self._download_url)
    local data = self:loadLocalData('train')

    -- train
    local start = 1
    local train_size = data[1]:size(1)
    --local train_size = 100    -- just for prototyping/debugging
    --local train_size = math.floor(data[1]:size(1) * self._valid_ratio)
    local size = math.floor(data[1]:size(1) * (1 - self._valid_ratio))
    self:trainSet(self:createDataSet(data[1]:narrow(1, start, train_size), data[2]:narrow(1, start, train_size), 'train'))

    -- valid
    if self._valid_ratio == 0 then
        print "Warning : No Valid Set due to valid_ratio == 0"
        return
    end
    local data = self:loadLocalData('train')
    start = size
    size = data[1]:size(1) - start
    self:validSet(self:createDataSet(data[1]:narrow(1, start, size), data[2]:narrow(1, start, size), 'valid'))
    return self:trainSet(), self:validSet()
end

function Biwi:loadTest()
    --local test_data = self:loadData(self._test_file, self._download_url)
    local test_data = self:loadLocalData('test')
    self:testSet(self:createDataSet(test_data[1], test_data[2], 'test'))
    return self:testSet()
end

--Creates a Biwi Dataset out of inputs, targets and which_set
function Biwi:createDataSet(inputs, targets, which_set)

    --print(inputs:size())
    --print(inputs[{1,{1,10},{1,10},1}])

    if self._shuffle then
        local indices = torch.randperm(inputs:size(1)):long()
        inputs = inputs:index(1, indices)
        targets = targets:index(1, indices)
    end
    if self._binarize then
        DataSource.binarize(inputs, 128)
    end
    --if self._scale and not self._binarize then
    --    DataSource.rescale(inputs, self._scale[1], self._scale[2])   -- causes NAN
    --end

    --print(targets:min())
    --print(targets:max())

    -- class 0 will have index 1, class 1 index 2, and so on.
    --targets:add(1)
    -- construct inputs and targets dp.Views
    local input_v, target_v = dp.ImageView(), dp.ClassView()
    input_v:forward(self._image_axes, inputs)
    target_v:forward('b', targets)
    target_v:setClasses(self._classes)
    -- construct dataset
    local ds = dp.DataSet { inputs = input_v, targets = target_v, which_set = which_set }
    ds:ioShapes('bhwc', 'b')

    return ds
end

function Biwi:loadData(file_name, download_url)
    local path = DataSource.getDataPath {
        name = self._name,
        url = download_url,
        decompress_file = file_name,
        data_dir = self._data_path
    }
    -- backwards compatible with old binary format
    local status, data = pcall(function() return torch.load(path, "ascii") end)
    if not status then
        return torch.load(path, "binary")
    end
    return data
end


--[[
tableToTensor(table)
  Takes a lua table and converts it to a torch.Tensor

Args:
  table (table): Lua table, can be any number of dimensions

Returns:
  tensor (torch.Tensor): Original lua table converted to a torch.Tensor
]]
function Biwi:tableToTensor(table)
    local tensorSize = table[1]:size()
    local tensorSizeTable = { -1 }
    for i = 1, tensorSize:size(1) do
        tensorSizeTable[i + 1] = tensorSize[i]
    end
    merge = nn.Sequential():add(nn.JoinTable(1)):add(nn.View(unpack(tensorSizeTable)))
    tensor = merge:forward(table)
    return tensor
end

function Biwi:loadLocalData(mode)

    if mode=='train' then
        dir_path = '/media/nikos/SSD1/depth_reid/BIWI/training/userMap_jpg_pad20/'
    else
        dir_path = '/media/nikos/SSD1/depth_reid/BIWI/testing/userMap_jpg_pad20_clean2/'
    end
    --dir_path = '/home/nikos/depth_reid/BIWI/' .. mode .. 'ing/userMap_jpg_pad20_clean/'

    local n_examples = 0
    local popen = io.popen
    local pfile = popen('ls -a "'..dir_path..'"')

    for filename in pfile:lines() do
        if filename~='.' and filename~='..' then
            n_examples = n_examples + 1
        end
    end
    pfile:close()

    idx = 1
    local X = torch.Tensor(n_examples, Biwi._image_size[2], Biwi._image_size[1], Biwi._image_size[3])
    local y = torch.Tensor(n_examples)

    local popen = io.popen
    local pfile = popen('ls -a "'..dir_path..'"')

    for filename in pfile:lines() do
        if filename~='.' and filename~='..' then
            file_path = dir_path .. filename
            label = tonumber(string.sub(filename,1,3)) + 1 -- Label must start at 1
            temp = image.load(file_path,3,'byte')
            --temp = image.scale(temp, 56, 144, 'bicubic'):permute(2,3,1)
            temp = image.scale(temp, 120, 160, 'bicubic'):permute(2,3,1)
            X[{ idx, {}, {}, {} }] = temp
            y[idx] = label
            idx = idx + 1
        end
    end

    pfile:close()

    result = { X, y }
    return result
end

function Biwi:scandir(directory)
    local i, t, popen = 0, {}, io.popen
    for filename in popen('ls "' .. directory .. '"'):lines() do
        i = i + 1
        t[i] = filename
    end
    return t
end
