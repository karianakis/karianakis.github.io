------------------------------------------------------------------------
--[[ TUM-GAID Dataset Loader ]] --
-- Nikolaos Karianakis
------------------------------------------------------------------------
require 'image'
require 'string'

local Tumgaid, DataSource = torch.class("dp.Tumgaid", "dp.DataSource")
Tumgaid.isTumgaid = true

Tumgaid._name = 'Tumgaid'
--Tumgaid._image_size = { 88, 128, 3 }
Tumgaid._image_size = { 56, 144, 3 }
Tumgaid._image_axes = 'bhwc'
--Tumgaid._feature_size = 1 * 88 * 128
Tumgaid._feature_size = 1 * 56 * 144
Tumgaid._classes = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
            41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
            81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120,
            121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155 }

function Tumgaid:__init(config)
    config = config or {}
    assert(torch.type(config) == 'table' and not config[1],
        "Constructor requires key-value arguments")
    local args, load_all, input_preprocess, target_preprocess
    args, self._valid_ratio, self._train_file, self._test_file,
    self._data_path, self._scale, self._binarize, self._shuffle,
    self._download_url, load_all, input_preprocess,
    target_preprocess
    = xlua.unpack({ config },
        'Tumgaid',
        'Tumgaid reidentification problem' ..
                'Note: Train and valid sets are already shuffled.',
        {
            arg = 'valid_ratio',
            type = 'number',
            default = 0,
            help = 'proportion of training set to use for cross-validation.'
        },
        {
            arg = 'train_file',
            type = 'string',
            default = 'train.th7',
            help = 'name of training file'
        },
        {
            arg = 'test_file',
            type = 'string',
            default = 'test.th7',
            help = 'name of test file'
        },
        {
            arg = 'data_path',
            type = 'string',
            default = '/local2/home/nikos/depth_reid/FaceBody/FaceBodyDepth/',
            help = 'path to data repository'
        },
        {
            arg = 'scale',
            type = 'table',
            help = 'bounds to scale the values between. [Default={0,1}]'
        },
        {
            arg = 'binarize',
            type = 'boolean',
            help = 'binarize the inputs (0s and 1s)',
            default = false
        },
        {
            arg = 'shuffle',
            type = 'boolean',
            help = 'shuffle different sets',
            default = false
        },
        {
            arg = 'download_url',
            type = 'string',
            default = '',
            help = 'URL from which to download dataset if not found on disk.'
        },
        {
            arg = 'load_all',
            type = 'boolean',
            help = 'Load all datasets : train, valid, test.',
            default = true
        },
        {
            arg = 'input_preprocess',
            type = 'table | dp.Preprocess',
            help = 'to be performed on set inputs, measuring statistics ' ..
                    '(fitting) on the train_set only, and reusing these to ' ..
                    'preprocess the valid_set and test_set.'
        },
        {
            arg = 'target_preprocess',
            type = 'table | dp.Preprocess',
            help = 'to be performed on set targets, measuring statistics ' ..
                    '(fitting) on the train_set only, and reusing these to ' ..
                    'preprocess the valid_set and test_set.'
        })
    if (self._scale == nil) then
        self._scale = { 0, 1 }
    end
    if load_all then
        --print('Loading training data...')
        --self:loadTrainValid()
        print('Loading test set data...')
        self:loadTest()
    end
    DataSource.__init(self, {
        train_set = self:trainSet(),
        valid_set = self:validSet(),
        test_set = self:testSet(),
        input_preprocess = input_preprocess,
        target_preprocess = target_preprocess
    })
end

function Tumgaid:loadTrainValid()
    --Data will contain a tensor where each row is an example, and where
    --the last column contains the target class.
    --local data = self:loadData(self._train_file, self._download_url)
    local data = self:loadLocalData('train')

    -- train
    local start = 1
    local train_size = data[1]:size(1)
    --local train_size = 40    -- just for prototyping/debugging
    -- local train_size = math.floor(data[1]:size(1) * self._valid_ratio)
    local size = math.floor(data[1]:size(1) * (1 - self._valid_ratio))
    self:trainSet(self:createDataSet(data[1]:narrow(1, start, train_size), data[2]:narrow(1, start, train_size), 'train'))

    -- valid
    if self._valid_ratio == 0 then
        print "Warning : No Valid Set due to valid_ratio == 0"
        return
    end
    local data = self:loadLocalData('train')
    start = size
    size = data[1]:size(1) - start
    self:validSet(self:createDataSet(data[1]:narrow(1, start, size), data[2]:narrow(1, start, size), 'valid'))
    return self:trainSet(), self:validSet()
end

function Tumgaid:loadTest()
    --local test_data = self:loadData(self._test_file, self._download_url)
    local test_data = self:loadLocalData('test')
    self:testSet(self:createDataSet(test_data[1], test_data[2], 'test'))
    return self:testSet()
end

--Creates a Tumgaid Dataset out of inputs, targets and which_set
function Tumgaid:createDataSet(inputs, targets, which_set)

    --print(inputs:size())
    --print(inputs[{1,{1,10},{1,10},1}])

    if self._shuffle then
        local indices = torch.randperm(inputs:size(1)):long()
        inputs = inputs:index(1, indices)
        targets = targets:index(1, indices)
    end
    if self._binarize then
        DataSource.binarize(inputs, 128)
    end
    --if self._scale and not self._binarize then
    --    DataSource.rescale(inputs, self._scale[1], self._scale[2])   -- causes NAN
    --end

    --print(targets:min())
    --print(targets:max())

    -- class 0 will have index 1, class 1 index 2, and so on.
    --targets:add(1)
    -- construct inputs and targets dp.Views
    local input_v, target_v = dp.ImageView(), dp.ClassView()
    input_v:forward(self._image_axes, inputs)
    target_v:forward('b', targets)
    target_v:setClasses(self._classes)
    -- construct dataset
    local ds = dp.DataSet { inputs = input_v, targets = target_v, which_set = which_set }
    ds:ioShapes('bhwc', 'b')

    return ds
end

function Tumgaid:loadData(file_name, download_url)
    local path = DataSource.getDataPath {
        name = self._name,
        url = download_url,
        decompress_file = file_name,
        data_dir = self._data_path
    }
    -- backwards compatible with old binary format
    local status, data = pcall(function() return torch.load(path, "ascii") end)
    if not status then
        return torch.load(path, "binary")
    end
    return data
end


--[[
tableToTensor(table)
  Takes a lua table and converts it to a torch.Tensor

Args:
  table (table): Lua table, can be any number of dimensions

Returns:
  tensor (torch.Tensor): Original lua table converted to a torch.Tensor
]]
function Tumgaid:tableToTensor(table)
    local tensorSize = table[1]:size()
    local tensorSizeTable = { -1 }
    for i = 1, tensorSize:size(1) do
        tensorSizeTable[i + 1] = tensorSize[i]
    end
    merge = nn.Sequential():add(nn.JoinTable(1)):add(nn.View(unpack(tensorSizeTable)))
    tensor = merge:forward(table)
    return tensor
end

function Tumgaid:loadLocalData(mode)
    dir_path_depth = '/media/nikos/SSD1/depth_reid/TUMGAID/TUMGAIDdepthtracked/croppedDepth/'
    dir_path_rgb = '/media/nikos/SSD1/depth_reid/TUMGAID/TUMGAIDimagetracked/croppedFrames/'

    local trainval_ids = { 1, 2, 4, 9, 10, 17, 20, 22, 23, 25, 26, 27, 28, 29, 31, 32, 34, 35, 36, 37, 38, 39, 41, 43, 44, 45, 46, 47, 49, 53, 54, 55, 56, 58, 59, 62, 65, 67, 68, 71, 75, 76,
     77, 79, 80, 83, 84, 85, 87, 88, 90, 93, 94, 99, 101, 102, 103, 108, 110, 114, 115, 123, 125, 126, 128, 129, 131, 132, 133, 134, 135, 137, 138, 139, 140, 142, 147, 148, 149, 150,
     154, 156, 157, 158, 163, 164, 165, 171, 172, 174, 175, 176, 177, 181, 186, 188, 192, 194, 195, 198, 201, 202, 203, 204, 205, 207, 209, 211, 212, 214, 215, 216, 217, 218, 219,
     223, 225, 228, 234, 235, 236, 239, 240, 244, 247, 248, 249, 252, 255, 256, 261, 262, 266, 270, 271, 272, 273, 276, 278, 280, 281, 283, 284, 285, 286, 289, 290, 292, 297, 303 }

    local test_ids = {3, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 18, 19, 21, 24, 30, 33, 40, 42, 48, 50, 51, 52, 57, 60, 61, 63, 64, 66, 69, 70, 72, 73, 74, 78, 81, 82, 86, 89, 91, 92, 95, 96, 97,
     98, 100, 104, 105, 106, 107, 109, 111, 112, 113, 116, 117, 118, 119, 120, 121, 122, 124, 127, 130, 136, 141, 143, 144, 145, 146, 151, 152, 153, 155, 159, 160, 161, 162, 166, 167, 168, 169,
     170, 173, 178, 179, 180, 182, 183, 184, 185, 187, 189, 190, 191, 193, 196, 197, 199, 200, 206, 208, 210, 213, 220, 221, 222, 224, 226, 227, 229, 230, 231, 232, 233, 237, 238, 241, 242,
     243, 245, 246, 250, 251, 253, 254, 257, 258, 259, 260, 263, 264, 265, 267, 268, 269, 274, 275, 277, 279, 282, 287, 288, 291, 293, 294, 295, 296, 298, 299, 300, 301, 302, 304, 305 }

    local ids

    if mode=='train' then
        seqs = {"n01", "n02", "n03", "n04"}
        ids = test_ids
    else
        seqs = {"n11", "n12"}

        ids = {}
        for i=1,16 do
            ids[#ids + 1] = test_ids[i]
        end
    end

    local id_count = 0
    for _ in pairs(ids) do id_count = id_count + 1 end
    --print(id_count)

    local seq_count = 0
    for _ in pairs(seqs) do seq_count = seq_count + 1 end

    local n_examples = 0
    local popen = io.popen

    for id=1,id_count do
    --for id=1,2 do
        id_dir_path = dir_path_depth .. 'p' .. string.format("%03d", ids[id]) .. '/'
        --print(id_dir_path)

        for seq_id = 1,seq_count do
            seq_dir_path = id_dir_path .. seqs[seq_id] .. '/gray/'
            --seq_dir_path = id_dir_path .. seqs[seq_id] .. '/face_4p/'
            --print(seq_dir_path)

            local seq_pfile = popen('ls -a "'..seq_dir_path..'"')
            for filename in seq_pfile:lines() do
                if filename~='.' and filename~='..' then
                    file_path = seq_dir_path .. filename
                    --print(file_path)
                    n_examples = n_examples + 1
                end
            end
            seq_pfile:close()
        end
    end

    idx = 1
    cur_label = 1
    local X = torch.Tensor(n_examples, Tumgaid._image_size[2], Tumgaid._image_size[1], Tumgaid._image_size[3])
    local y = torch.Tensor(n_examples)

    local popen = io.popen
    for id=1,id_count do
    --for id=1,2 do
        id_dir_path = dir_path_depth .. 'p' .. string.format("%03d", ids[id]) .. '/'
        --print(id_dir_path)

        label = cur_label
        cur_label = cur_label+1

        for seq_id = 1,seq_count do
            seq_dir_path = id_dir_path .. seqs[seq_id] .. '/gray/'
            --seq_dir_path = id_dir_path .. seqs[seq_id] .. '/face_4p/'
            --print(seq_dir_path)

            local seq_pfile = popen('ls -a "'..seq_dir_path..'"')
            for filename in seq_pfile:lines() do
                if filename~='.' and filename~='..' then
                    --file_path = seq_dir_path .. filename
                    --file_path = id_dir_path .. seqs[seq_id] .. '/face_4p/' .. filename
                    file_path = dir_path_rgb .. 'p' .. string.format("%03d", ids[id]) .. '/' .. seqs[seq_id] .. '/' .. string.sub(filename,1,3) .. '.png'
                    --print(file_path)

                    temp = image.load(file_path,3,'byte')
                    temp = image.scale(temp, 56, 144, 'bicubic'):permute(2,3,1)
                    X[{ idx, {}, {}, {} }] = temp
                    y[idx] = label
                    idx = idx + 1
                end
            end
            seq_pfile:close()
        end
    end

    result = { X, y }
    return result
end

function Tumgaid:scandir(directory)
    local i, t, popen = 0, {}, io.popen
    for filename in popen('ls "' .. directory .. '"'):lines() do
        i = i + 1
        t[i] = filename
    end
    return t
end
