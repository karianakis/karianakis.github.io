------------------------------------------------------------------------
-- Reinforced Temporal Attention: Nikolaos Karianakis
-- Recurrent Attention Models: https://github.com/Element-Research/rnn, Albert Haque
------------------------------------------------------------------------
--[[ RecurrentAttention ]] --
-- Ref. A. http://papers.nips.cc/paper/5542-recurrent-models-of-visual-attention.pdf
-- B. http://incompleteideas.net/sutton/williams-92.pdf
-- module which takes an RNN as argument with other 
-- hyper-parameters such as the maximum number of steps, 
-- action (actions sampling module like ReinforceNormal) and 
------------------------------------------------------------------------
local RecurrentAttention, parent = torch.class("nn.RecurrentAttention", "nn.AbstractSequencer")

--function RecurrentAttention:__init(rnn, action, nStep, hiddenSize)
function RecurrentAttention:__init(rnn, action, glimpse_input, frame_importance, nStep, hiddenSize)

    parent.__init(self)
    assert(torch.isTypeOf(action, 'nn.Module'))
    assert(torch.type(nStep) == 'number')
    assert(torch.type(hiddenSize) == 'table')
    assert(torch.type(hiddenSize[1]) == 'number', "Does not support table hidden layers")

    self.rnn = rnn
    -- we can decorate the module with a Recursor to make it AbstractRecurrent
    self.rnn = (not torch.isTypeOf(rnn, 'nn.AbstractRecurrent')) and nn.Recursor(rnn) or rnn

    -- samples an x,y actions for each example
    self.action = (not torch.isTypeOf(action, 'nn.AbstractRecurrent')) and nn.Recursor(action) or action

    -- samples the frame importance
    self.frame_importance = frame_importance
    self.glimpse_input = glimpse_input

    self.hiddenSize = hiddenSize
    self.nStep = nStep

    --self.modules = { self.rnn, self.action }
    self.modules = { self.rnn, self.action, self.frame_importance, self.glimpse_input }

    self.output = {} -- rnn output
    self.actions = {} -- action output

    self:buildEncoderModule()

    self.forwardActions = false

    self.gradHidden = {}
end

-- build encoder    ADDED
function RecurrentAttention:buildEncoderModule()
    self.encoderModule = nn.Sequential()
    self.encoderModule:add(self.glimpse_input)
end

function RecurrentAttention:updateOutput(input)
    -- 'input' is the input image frame
    self.rnn:forget()
    self.action:forget()
    self.frame_importance:forget()
    local nDim = input:dim()
    local output
    local encoding
    local importance

    --temp = torch.ones(input:size()[1], 1)

    for step = 1, self.nStep do

        if step == 1 then
            -- Spatial attention -> (x,y) locator: sample an initial starting actions by forwarding zeros through the action
            --self._initInput = self._initInput or input.new()
            --self._initInput:resize(input:size(1), table.unpack(self.hiddenSize)):zero()
            --self.actions[1] = self.action:updateOutput(self._initInput)

            -- rnn handles the recurrence internally
            -- the location (x,y) is ignored in our framework, since we use the whole image and the location sensor has been removed
            --output = self.rnn:updateOutput { input, self.actions[step] }
            output = self.rnn:updateOutput(input)

            -- Temporal attention -> calculate frame importance w for current batch
            encoding = self.encoderModule:updateOutput(input)
            importance = self.frame_importance:updateOutput(encoding)       -- RTA
            --importance = self.frame_importance:updateOutput({ self._initInput, encoding })  -- classic temporal att
            self.actions[1] = importance

            -- store the testing weights (frame importance) - executed here (instead of Recurrent.lua) to avoid repetition for rho times
            --w_txt = io.open("/home/nikos/depth_reid/ram_person_id/src/eval/tumgaid/weights_rgb_rnn_rho3_do_noS_att_ep5.txt", "a")
            --for i=1,50 do                               -- batch size
            --    w_txt:write(importance[i][1])
            --    w_txt:write("\n")
            --end
            --io.close(w_txt)
        else
            -- rotate the input batch along the 1st dim (in order to process the sequence sequentially; no shuffling allowed)
            --shift = step-1
            --b_size = input:size()[1]
            --shifted_input = torch.Tensor():resizeAs(input)
            --shifted_input[{{b_size-shift+1, b_size}, {}, {}, {}}] = input[{{1,shift}, {}, {}, {}}]
            --shifted_input[{{1, b_size-shift}, {}, {}, {}}] = input[{{shift+1, b_size}, {}, {}, {}}]

            -- Spatial attention -> (x,y) locator: sample actions from previous hidden activation (rnn output)
            --self.actions[step] = self.action:updateOutput(self.output[step-1])

            -- rnn handles the recurrence internally
            -- the location (x,y) is ignored in our framework, since we use the whole image and the location sensor has been removed
            --output = self.rnn:updateOutput { shifted_input, temp }
            --output = self.rnn:updateOutput { input, self.actions[step] }
            output = self.rnn:updateOutput(input)

            -- Temporal attention -> calculate frame importance w for (optionally shifted) current batch
            encoding = self.encoderModule:updateOutput(input)
            importance = self.frame_importance:updateOutput(encoding)      -- RTA
            --importance = self.frame_importance:updateOutput({ self.output[step-1], encoding })  -- classic temporal att
            self.actions[step] = importance
        end

        self.output[step] = self.forwardActions and { output, self.actions[step] } or output
    end

    return self.output
end

function RecurrentAttention:updateGradInput(input, gradOutput)
    assert(self.rnn.step - 1 == self.nStep, "inconsistent rnn steps")
    assert(torch.type(gradOutput) == 'table', "expecting gradOutput table")
    assert(#gradOutput == self.nStep, "gradOutput should have nStep elements")

    local encoding

    -- back-propagate through time (BPTT)
    for step = self.nStep, 1, -1 do
        --local gradOutput_, gradAction_ = gradOutput[step]     -- RSA
        local gradOutput_, gradImportance_ = gradOutput[step]   -- RTA

        if self.forwardActions then
            --gradOutput_, gradAction_ = unpack(gradOutput[step])    -- RSA
            gradOutput_, gradImportance_ = unpack(gradOutput[step])  -- RTA
        else
            -- Note : gradOutput is ignored by REINFORCE modules so we give a zero Tensor instead

            -- RSA
            --self._gradAction = self._gradAction or self.action.output.new()
            --if not self._gradAction:isSameSizeAs(self.action.output) then
            --    self._gradAction:resizeAs(self.action.output):zero()
            --end
            --gradAction_ = self._gradAction

            -- RTA
            self._gradImportance = self._gradImportance or self.frame_importance.output.new()
            if not self._gradImportance:isSameSizeAs(self.frame_importance.output) then
                self._gradImportance:resizeAs(self.frame_importance.output):zero()
            end
            gradImportance_ = self._gradImportance
        end

        if step == self.nStep then
            self.gradHidden[step] = nn.rnn.recursiveCopy(self.gradHidden[step], gradOutput_)
        else
            -- gradHidden = gradOutput + gradAction for spatial attention (RSA) and classic temporal attention
            --nn.rnn.recursiveAdd(self.gradHidden[step], gradOutput_)

            -- gradHidden = gradOutput for reinforced temporal attention (RTA), as the gradImportance is backpropagated to the CNN encoder (and ignored for fixed CNN)
            self.gradHidden[step] = nn.rnn.recursiveCopy(self.gradHidden[step], gradOutput_)
        end

        -- 1. backward through the action layers
        if step == 1 then
            -- RSA: backward through initial starting actions
            --self.action:updateGradInput(self._initInput, gradAction_)

            -- RTA (the output gradient can be ignored when we do not update the CNN weights)
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:updateGradInput(encoding, gradImportance_)

            -- Classic temporal attention
            --self.frame_importance:updateGradInput({ self._initInput, encoding }, gradImportance_)
        else
            -- RSA
            --local gradAction = self.action:updateGradInput(self.output[step - 1], gradAction_)
            --self.gradHidden[step - 1] = nn.rnn.recursiveCopy(self.gradHidden[step - 1], gradAction)

            --shift = step-1
            --b_size = input:size()[1]
            --shifted_input = torch.Tensor():resizeAs(input)
            --shifted_input[{{b_size-shift+1, b_size}, {}, {}, {}}] = input[{{1,shift}, {}, {}, {}}]
            --shifted_input[{{1, b_size-shift}, {}, {}, {}}] = input[{{shift+1, b_size}, {}, {}, {}}]

            -- RTA (the output gradient can be ignored when we do not update the CNN weights)
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:updateGradInput(encoding, gradImportance_)

            -- Classic temporal attention
            --local gradImportance = self.frame_importance:updateGradInput({ self.output[step - 1], encoding }, gradImportance_)
            --self.gradHidden[step - 1] = nn.rnn.recursiveCopy(self.gradHidden[step - 1], gradImportance[1])
        end

        -- 2. backward through the rnn layer
        --local gradInput = self.rnn:updateGradInput({ input, self.actions[step] }, self.gradHidden[step])[1]     -- RSA
        local gradInput = self.rnn:updateGradInput(( input ), self.gradHidden[step])[1]                          -- RTA

        if step == self.nStep then
            self.gradInput:resizeAs(gradInput):copy(gradInput)
        else
            self.gradInput:add(gradInput)
        end
    end

    return self.gradInput
end

function RecurrentAttention:accGradParameters(input, gradOutput, scale)
    assert(self.rnn.step - 1 == self.nStep, "inconsistent rnn steps")
    assert(torch.type(gradOutput) == 'table', "expecting gradOutput table")
    assert(#gradOutput == self.nStep, "gradOutput should have nStep elements")

    local encoding

    -- back-propagate through time (BPTT)
    for step = self.nStep, 1, -1 do
        --local gradAction_ = self.forwardActions and gradOutput[step][2] or self._gradAction         -- RSA
        local gradImportance_ = self.forwardActions and gradOutput[step][2] or self._gradImportance   -- RTA

        if step == 1 then
            -- 1. backward through the action layers
            -- RSA: backward through initial starting actions
            --self.action:accGradParameters(self._initInput, gradAction_, scale)

            -- RTA (the output gradient can be ignored when we do not update the CNN weights)
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:accGradParameters(encoding, gradImportance_, scale)

            -- Classic temporal attention
            --self.frame_importance:accGradParameters({ self._initInput, encoding }, gradImportance_, scale)

            -- 2. backward through the rnn layer
            --self.rnn:accGradParameters({ input, self.actions[step] }, self.gradHidden[step], scale)  -- RSA
            self.rnn:accGradParameters(( input ), self.gradHidden[step], scale)                        -- RTA
        else
            -- 1. backward through the action layers
            -- RSA
            --self.action:accGradParameters(self.output[step - 1], gradAction_, scale)

            --shift = step-1
            --b_size = input:size()[1]
            --shifted_input = torch.Tensor():resizeAs(input)
            --shifted_input[{{b_size-shift+1, b_size}, {}, {}, {}}] = input[{{1,shift}, {}, {}, {}}]
            --shifted_input[{{1, b_size-shift}, {}, {}, {}}] = input[{{shift+1, b_size}, {}, {}, {}}]

            -- RTA
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:accGradParameters(encoding, gradImportance_, scale)

            -- Classic temporal attention
            --self.frame_importance:accGradParameters({ self.output[step - 1], encoding }, gradImportance_, scale)

            -- 2. backward through the rnn layer
            --self.rnn:accGradParameters({ shifted_input, self.actions[step] }, self.gradHidden[step], scale)   -- RSA
            self.rnn:accGradParameters(( input ), self.gradHidden[step], scale)                                 -- RTA
        end
    end
end

function RecurrentAttention:accUpdateGradParameters(input, gradOutput, lr)
    assert(self.rnn.step - 1 == self.nStep, "inconsistent rnn steps")
    assert(torch.type(gradOutput) == 'table', "expecting gradOutput table")
    assert(#gradOutput == self.nStep, "gradOutput should have nStep elements")

    local encoding

    -- backward through the action layers
    for step = self.nStep, 1, -1 do
        --local gradAction_ = self.forwardActions and gradOutput[step][2] or self._gradAction        -- RSA
        local gradImportance_ = self.forwardActions and gradOutput[step][2] or self._gradImportance  -- RTA

        if step == 1 then
            -- 1. backward through the action layers
            -- RSA: backward through initial starting actions
            --self.action:accUpdateGradParameters(self._initInput, gradAction_, lr)

            -- RTA
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:accUpdateGradParameters(encoding, gradImportance_, lr)

            -- Classic temporal attention
            --self.frame_importance:accUpdateGradParameters({ self._initInput, encoding }, gradImportance_, lr)

            -- 2. backward through the rnn layer
            --self.rnn:accUpdateGradParameters({ input, self.actions[step] }, self.gradHidden[step], lr)   -- RSA
            self.rnn:accUpdateGradParameters(( input ), self.gradHidden[step], lr)                         -- RTA
        else
            -- 1. backward through the action layers - Note : gradOutput is ignored by REINFORCE modules so we give action.output as a dummy variable
            -- RSA
            --self.action:accUpdateGradParameters(self.output[step - 1], gradAction_, lr)

            --shift = step-1
            --b_size = input:size()[1]
            --shifted_input = torch.Tensor():resizeAs(input)
            --shifted_input[{{b_size-shift+1, b_size}, {}, {}, {}}] = input[{{1,shift}, {}, {}, {}}]
            --shifted_input[{{1, b_size-shift}, {}, {}, {}}] = input[{{shift+1, b_size}, {}, {}, {}}]

            -- RTA
            encoding = self.encoderModule:updateOutput(input)
            self.frame_importance:accUpdateGradParameters(encoding, gradImportance_, lr)

            -- Classic temporal attention
            --self.frame_importance:accUpdateGradParameters({ self.output[step - 1], encoding }, gradImportance_, lr)

            -- 2. backward through the rnn layer
            --self.rnn:accUpdateGradParameters({ input, self.actions[step] }, self.gradHidden[step], lr)   -- RSA
            self.rnn:accUpdateGradParameters(( input ), self.gradHidden[step], lr)                         -- RTA
        end
    end
end

function RecurrentAttention:type(type)
    self._input = nil
    self._actions = nil
    self._crop = nil
    self._pad = nil
    self._byte = nil
    return parent.type(self, type)
end

function RecurrentAttention:__tostring__()
    local tab = '  '
    local line = '\n'
    local ext = '  |    '
    local extlast = '       '
    local last = '   ... -> '
    local str = torch.type(self)
    str = str .. ' {'
    --str = str .. line .. tab .. 'action : ' .. tostring(self.action):gsub(line, line .. tab .. ext)
    str = str .. line .. tab .. 'frame importance : ' .. tostring(self.frame_importance):gsub(line, line .. tab .. ext)
    str = str .. line .. tab .. 'rnn     : ' .. tostring(self.rnn):gsub(line, line .. tab .. ext)
    str = str .. line .. '}'
    return str
end
