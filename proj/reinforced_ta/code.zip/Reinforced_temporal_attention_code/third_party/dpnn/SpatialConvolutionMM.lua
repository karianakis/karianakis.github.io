local SpatialConvolutionMM, parent = nn.SpatialConvolutionMM, nn.Module

SpatialConvolutionMM.dpnn_mediumEmpty = nn.SpatialConvolution.dpnn_mediumEmpty
