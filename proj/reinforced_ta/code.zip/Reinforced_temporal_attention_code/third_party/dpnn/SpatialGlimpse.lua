
------------------------------------------------------------------------
-- Reinforced Temporal Attention: Nikolaos Karianakis
-- Recurrent Attention Models: https://github.com/Element-Research/rnn, Albert Haque
------------------------------------------------------------------------
--[[ SpatialGlimpse ]] --
-- Ref A.: http://papers.nips.cc/paper/5542-recurrent-models-of-visual-attention.pdf
-- a glimpse is the concatenation of down-scaled cropped images of
-- increasing scale around a given location in a given image.
-- input is a pair of Tensors: {image, location}
-- locations are x,y coordinates of the center of cropped patches.
-- Coordinates are between -1,-1 (top-left) and 1,1 (bottom right)
-- output is a batch of glimpses taken in image at location (x,y)
-- glimpse size is {height, width}, or width only if square-shaped
-- depth is number of patches to crop per glimpse (one patch per scale)
-- Each successive patch is scale x size of the previous patch
------------------------------------------------------------------------

npy4th = require 'npy4th'

local SpatialGlimpse, parent = torch.class("nn.SpatialGlimpse", "nn.Module")

--[[
-- 	SpatialGlimpse:__init(encoder, width, n_patch, blur)
-- 		Creates a spatial glimpse module. The spatial glimpse module takes as input
-- 		an image and a location, and will output an embedding representing the glimpse.
--
--	Args:
--		encoder: nn.module trained offline
--		width: Width of a single glimpse patch
--		n_patch: number of patches in the glimpse
--		blue: Blur scale (default=2 for quadratic)
--]]
function SpatialGlimpse:__init(encoder, size, depth, blur)
    dpnn.require('nnx')
    if torch.type(size)=='table' then
      self.height = size[1]
      self.width = size[2]
    else
      self.width = size
      self.height = size
    end

    -- Encoder model trained offline
    self.encoder = encoder

    -- Width of a single patch, namely, the center most
    -- self.width = width
    -- Number of consecutive patches
    self.depth = depth
    -- Blur scale. The nth patch is downsampled by blur^n
    self.blur = blur

    assert(torch.type(self.width) == 'number')
    assert(torch.type(self.height) == 'number')
    assert(torch.type(self.depth) == 'number')
    assert(torch.type(self.blur) == 'number')

    -- The final glimpse width and height. This is the size input into the encoder
    self.glimpse_width = self.width * depth
    self.glimpse_height = self.height * depth

    parent.__init(self)
    --self.gradInput = { torch.Tensor(), torch.Tensor() }
    self.gradInput = torch.Tensor()

    self.modules = self.encoder
end

--[[
--	SpatialGlimpse:updateOutput(inputTable)
-- 		Performs the actual glimpse extraction and encoding process.
--
--	Args
--		inputTable: Contains the input (image) and the glimpse location
--			[1] input_imgs of size (batch_size, channels, width, height)
--			[2] location of size (batch_size, n_dim)
--
--	Returns
--		output: The result of a "forward pass" through this spatial glimpse module.
--			The output will be a matrix representing the encoded embeddings of the glimpses.
--]]
function SpatialGlimpse:updateOutput(inputTable)

    --local input_imgs, location = unpack(inputTable)
    --input_imgs, location = self:toBatch(input_imgs, 3), self:toBatch(location, 1)

    local input_imgs = inputTable
    input_imgs = self:toBatch(input_imgs, 3)

    -- input: (batch_size, channels, width, height)
    -- location: (batch_size, 2)
    -- dim = location:dim()

    -- embedding_size = 256 -- Depends on the pre-trained autoencoder

    local batch_size = input_imgs:size()[1]
    local input_glimpses = torch.Tensor(batch_size, 3, self.glimpse_height, self.glimpse_width) -- replicate at 2nd dim

    -- local scales = {}
    -- for i = 1, self.depth do scales[i] = 1 / math.pow(i, self.blur) end
    -- Check if input location, when converted to H, W is in image bounds
    --location[{ {}, 1 }] = torch.clamp(torch.round(location[{ {}, 1 }] * 120) + 120, 80, 160)
    --location[{ {}, 2 }] = torch.clamp(torch.round(location[{ {}, 2 }] * 160) + 160, 80, 240)
    --location[{ {}, 1 }] = 120
    --location[{ {}, 2 }] = 160

    --local gw2 = math.floor(self.glimpse_width / 2)
    --local gh2 = math.floor(self.glimpse_height / 2)
    -- local gw2 = 100    -- extract 200x200 glipmses mod the frame boundaries
    -- local gh2 = 100

    -- For each image in the batch, extract the glimpse
    for i = 1, batch_size do
        x = input_imgs[i]

        --phi = location[i]

        -- Get the full resolution hypercube centered at phi
        -- Find the start and end index of the hypercube
        --local slice = {}
        -- for d = 1, dim do
        --table.insert(slice, { math.max(1, phi[1] - gh2 + 1), math.min(phi[1] + gh2, 240) })
        --table.insert(slice, { math.max(1, phi[2] - gw2 + 1), math.min(phi[2] + gw2, 320) })
        -- end
        -- Index 1 for 1st dim due to #channels as first index

        --hypercube = x[1][slice]

        -- Downsample the input. Create progressively downsampled patches
        -- local pyramid = image.gaussianpyramid(hypercube, scales)
        -- Scale all back to side length = glimpse_width
        -- for i = 1, #pyramid do
            -- pyramid[i] = image.scale(pyramid[i], self.glimpse_width, self.glimpse_height)
        -- end

        -- Combine all patches into single tensor
        -- glimpse = torch.zeros(pyramid[1]:size())
        -- for i = 1, #pyramid do
            -- local corner1_h = (i - 1) * (self.height / 2) + 1
            -- local corner2_h = self.glimpse_height - corner1_h + 1
            -- local corner1_w = (i - 1) * (self.width / 2) + 1
            -- local corner2_w = self.glimpse_width - corner1_w + 1
            -- local slice = {}
            -- for j = 1, dim do
            -- table.insert(slice, { corner1_h, corner2_h })
            -- table.insert(slice, { corner1_w, corner2_w })
            -- end
            -- glimpse[slice] = pyramid[#pyramid - (i - 1)][slice]
        -- end

        --print(x[{{1,3},{1,2},{1,2}}])

        -- rescale image from original resolution (after data reading) to 56x144
        --hypercube = image.scale(x, 56, 144, 'bicubic')
        hypercube = x

        -- convert RGB to BGR
        local perm = torch.LongTensor{3, 2, 1}
        hypercube = hypercube:index(1, perm)

        -- subtract mean image (already in BGR form, as the trained model)
        mean_image = npy4th.loadnpy('/media/nikos/SSD/depth_reid/DPI-T/partitions/depth_dpit_train_mean.npy'):float()

        --print(hypercube[{{1,3},{1,2},{1,2}}])
        --print(mean_image[{{1,3},{1,2},{1,2}}])
        --dif = hypercube-mean_image
        --print(dif[{{1,3},{1,2},{1,2}}])

        input_glimpses[{ i, {}, {}, {} }] = hypercube-mean_image
    end

    -- Forward pass
    input_glimpses = input_glimpses:cuda()
    self.encoder = self.encoder:cuda()

    self.output = self.encoder:forward(input_glimpses)
    -- self.output = self.encoder:get(1).output
    self.output = self.output:float()

    --print(self.output:size())
    --print(self.output[{{1,batch_size},{1,4}}])

    return self.output
end

--[[
 SpatialGlimpse:updateGradInput(inputTable, gradOutput)
    Controls the gradient flow through this module. For our spatial glimpse,
    we do not want any gradients updating the encoder.

]]
function SpatialGlimpse:updateGradInput(inputTable, gradOutput)

    -- Do not update any gradients
    --local input, location = unpack(inputTable)
    --local gradInput, gradLocation = unpack(self.gradInput)
    --input, location = self:toBatch(input, 3), self:toBatch(location, 1)

    local input = inputTable
    local gradInput = self.gradInput
    input = self:toBatch(input, 3)

    -- input is of size (batch_size, n_channel, img H, img W)
    gradInput:resizeAs(input):zero()
    --gradLocation:resizeAs(location):zero()

    --    gradOutput = gradOutput:view(input:size(1), self.depth, input:size(2), self.height, self.width)
    --
    --    for sampleIdx = 1, gradOutput:size(1) do
    --        local gradOutputSample = gradOutput[sampleIdx]
    --        local gradInputSample = gradInput[sampleIdx]
    --        local yx = location[sampleIdx] -- height, width
    --        -- (-1,-1) top left corner, (1,1) bottom right corner of image
    --        local y, x = yx:select(1, 1), yx:select(1, 2)
    --        -- (0,0), (1,1)
    --        y, x = (y + 1) / 2, (x + 1) / 2
    --
    --        -- for each depth of glimpse : pad, crop, downscale
    --        local glimpseWidth = self.width
    --        local glimpseHeight = self.height
    --        for depth = 1, self.depth do
    --            local src = gradOutputSample[depth]
    --            if depth > 1 then
    --                glimpseWidth = glimpseWidth * self.scale
    --                glimpseHeight = glimpseHeight * self.scale
    --            end
    --
    --            -- add zero padding (glimpse could be partially out of bounds)
    --            local padWidth = math.floor((glimpseWidth - 1) / 2)
    --            local padHeight = math.floor((glimpseHeight - 1) / 2)
    --            self._pad:resize(input:size(2), input:size(3) + padHeight * 2, input:size(4) + padWidth * 2):zero()
    --
    --            local h, w = self._pad:size(2) - glimpseHeight, self._pad:size(3) - glimpseWidth
    --            local y, x = math.min(h, math.max(0, y * h)), math.min(w, math.max(0, x * w))
    --            local pad = self._pad:narrow(2, y + 1, glimpseHeight):narrow(3, x + 1, glimpseWidth)
    --
    --            -- upscale glimpse for different depths
    --            if depth == 1 then
    --                pad:copy(src)
    --            else
    --                self._crop:resize(input:size(2), glimpseHeight, glimpseWidth)
    --
    --                if torch.type(self.module) == 'nn.SpatialAveragePooling' then
    --                    local poolWidth = glimpseWidth / self.width
    --                    assert(poolWidth % 2 == 0)
    --                    local poolHeight = glimpseHeight / self.height
    --                    assert(poolHeight % 2 == 0)
    --                    self.module.kW = poolWidth
    --                    self.module.kH = poolHeight
    --                    self.module.dW = poolWidth
    --                    self.module.dH = poolHeight
    --                end
    --
    --                pad:copy(self.module:updateGradInput(self._crop, src))
    --            end
    --
    --            -- copy into gradInput tensor (excluding padding)
    --            gradInputSample:add(self._pad:narrow(2, padHeight + 1, input:size(3)):narrow(3, padWidth + 1, input:size(4)))
    --        end
    --    end

    --self.gradInput[1] = self:fromBatch(gradInput, 1)
    --self.gradInput[2] = self:fromBatch(gradLocation, 1)

    self.gradInput = self:fromBatch(gradInput, 1)

    return self.gradInput
end
