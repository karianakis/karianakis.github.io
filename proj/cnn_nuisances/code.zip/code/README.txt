Provided scripts:
=> The source code in eval_PDC_cnn_imagenet.m supports all (or any subset of) 
   augmentation techniques which are proposed in:

   An Empirical Evaluation of Current Convolutional Architectures’ Ability
   to Manage Nuisance Location and Scale Variability.
   N. Karianakis, J. Dong, and S. Soatto. CVPR 2016.

   You can reproduce results from Table 2 by choosing sampling techniques:
   P_flag = true;       % (P)roposals
   D_flag = true;       % (D)omain sizes
   C_flag = true;       % (C)rops (also choose number of scales and crops)

=> eval_cnn_imagenet_gt_ds.m reproduces the experiments in Figure 1 and Table 1.

Dependencies:
-- The experiments in the paper have been conducted with MatConvNet library (v16).
   Newer versions of the library may lead to faster execution.

   Additionally, the latest pretrained models uploaded in MatConvnet (with v18 and after)
   can improve performance across the table (which has already been observed for VGG16).

   In order to use our method you need to download MatConvNet (v16 or newer) and replace 
   cnn_imagenet_get_batch.m in directory ~/examples/imagenet/ with our cnn_imagenet_get_batch.m

-- You also need to download the Structured Edge Detection Toolbox V3.0, 
   which our proposal generation relies on. Note that other proposal algorithms,
   except for Edge Boxes, could work as well, as far as they are tuned properly.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% Copyright (c) 2015-2016, Nikolaos Karianakis. University of California, Los Angeles. %
% All rights reserved.                                                                 %
%                                                                                      %
% This is free software: you can redistribute it and/or modify it under the terms      %
% of the GNU General Public License as published by the Free Software Foundation,      %
% either version 3 of the License, or (at your option) any later version.              %
%                                                                                      %
% The software is distributed in the hope that it will be useful, but WITHOUT ANY      %
% WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A      %
% PARTICULAR PURPOSE.  See the GNU General Public License for more details.            %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% This software uses MatConvNet as its building block. The license of the latter       %
% is attached as required.                                                             %
%                                                                                      %
% Copyright (c) 2014-16 The MatConvNet team.                                           %
% All rights reserved.                                                                 %
%                                                                                      %
% MatConvNet was originally created by Andrea Vedaldi and Karel Lenc and it is         %
% currently developed by a small community of contributors. It is distributed under    %
% the permissive BSD license.                                                          %
%                                                                                      %
% This software also uses the Structured Edge Detection Toolbox V3.0                   %
%    Piotr Dollar (pdollar-at-gmail.com)                                               %
% which is published under the MSR-LA Full Rights License.                             %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
