%% Modified (from MatConvNet v16) by Nikolaos Karianakis to support augmentation with three scales.

function imo = cnn_imagenet_get_batch(images, averageImage, net_input_size, augm_scheme, scale)
% CNN_IMAGENET_GET_BATCH  Load, preprocess, and pack images for CNN evaluation

opts.imageSize = [net_input_size, net_input_size];
opts.border = [29, 29];

opts.averageImage = averageImage;
%opts.averageImage = [];

opts.rgbVariance = zeros(0,3,'single') ;

opts.augmentation = augm_scheme;
if strcmp(augm_scheme, 'f5')
	opts.numAugments = 10;
elseif strcmp(augm_scheme, 'f25')
	opts.numAugments = 50;
else
	opts.numAugments = 1;
end

opts.interpolation = 'bilinear';
opts.numThreads = 4;
opts.prefetch = false;
opts.keepAspect = true;
%opts = vl_argparse(opts, varargin);

% fetch is true if images is a list of filenames (instead of
% a cell array of images)
fetch = numel(images) > 1 && ischar(images{1});

% prefetch is used to load images in a separate thread
prefetch = fetch & opts.prefetch;

switch opts.augmentation
	case 'none'
		tfs = [.5 ; .5 ; 0 ];
	case 'f5'
		tfs = [...
			.5 0 0 1 1 .5 0 0 1 1;
			.5 0 1 0 1 .5 0 1 0 1;
			0 0 0 0 0  1 1 1 1 1];
	case 'f25'
		[tx,ty] = meshgrid(linspace(0,1,5));
		tfs = [tx(:)' ; ty(:)' ; zeros(1,numel(tx))];
		tfs_ = tfs;
		tfs_(3,:) = 1;
		tfs = [tfs,tfs_];
end

im = cell(1, numel(images));
if opts.numThreads > 0
	if prefetch
		vl_imreadjpeg(images, 'numThreads', opts.numThreads, 'prefetch');
		imo = [] ;
		return ;
	end
	if fetch
		im = vl_imreadjpeg(images,'numThreads', opts.numThreads);
	end
end
if ~fetch
	im = images;
end

imo = zeros(opts.imageSize(1), opts.imageSize(2), 3, ...
		numel(images)*opts.numAugments*scale, 'single');

[~,augmentations] = sort(rand(size(tfs,2), numel(images)), 1);

si = 1;
for i=1:numel(images)
	% acquire image
	if isempty(im{i})
		imt_orig = imread(images{i});
		imt_orig = single(imt_orig) ; % faster than im2single (and multiplies by 255)
	else
		imt_orig = im{i};
	end
	if size(imt_orig,3) == 1
		imt_orig = cat(3, imt_orig, imt_orig, imt_orig);
	end
	% resize
	w = size(imt_orig,2);
	h = size(imt_orig,1);
	if (scale == 1)
		factor = [(opts.imageSize(1)+opts.border(1))/h  (opts.imageSize(2)+opts.border(2))/w];
	else
		factor = [(opts.imageSize(1)+opts.border(1))/h  (opts.imageSize(2)+opts.border(2))/w;
				opts.imageSize(1)/h  opts.imageSize(2)/w;
				(opts.imageSize(1)+2*opts.border(1))/h  (opts.imageSize(2)+2*opts.border(2))/w];
	end

	if opts.keepAspect
		factor = max(factor,[],2);
	end

	for sc=1:scale
		if any(abs(factor(sc,:) - 1) > 0.0001)
			imt = imresize(imt_orig, 'scale', factor(sc,:), 'method', opts.interpolation);  % resize so that at least 1 dim being 256
		else
			imt = imt_orig;
		end

		% in case of subtracting the average before cropping
		%resc_aver_image = imresize(opts.averageImage, [size(imt, 1) size(imt, 2)]);
		%imt = imt - resc_aver_image;

		% crop & flip
		w = size(imt,2);
		h = size(imt,1);
		for ai = 1:opts.numAugments
			t = augmentations(ai,i);
			tf = tfs(:,t);
			dx = floor((w - opts.imageSize(2)) * tf(2));
			dy = floor((h - opts.imageSize(1)) * tf(1));
			sx = (1:opts.imageSize(2)) + dx;
			sy = (1:opts.imageSize(1)) + dy;
			if tf(3), sx = fliplr(sx) ; end

			temp = imt(sy,sx,:);
			imo(:,:,:,si) = imresize(temp, [opts.imageSize(1) opts.imageSize(2)]);
			%end
			si = si + 1;
		end
	end
end

if ~isempty(opts.averageImage)
	offset = opts.averageImage;
	if ~isempty(opts.rgbVariance)
		offset = bsxfun(@plus, offset, reshape(opts.rgbVariance * randn(3,1), 1,1,3));
	end
	imo = bsxfun(@minus, imo, offset);
end
