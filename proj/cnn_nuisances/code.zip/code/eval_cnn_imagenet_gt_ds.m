%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% Copyright (c) 2015-2016, Nikolaos Karianakis. University of California, Los Angeles. %
% All rights reserved.                                                                 %
%                                                                                      %
% This is free software: you can redistribute it and/or modify it under the terms      %
% of the GNU General Public License as published by the Free Software Foundation,      %
% either version 3 of the License, or (at your option) any later version.              %
%                                                                                      %
% The software is distributed in the hope that it will be useful, but WITHOUT ANY      %
% WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A      %
% PARTICULAR PURPOSE.  See the GNU General Public License for more details.            %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% This software uses MatConvNet as its building block. The license of the latter       %
% is attached as required.                                                             %
%                                                                                      %
% Copyright (c) 2014-16 The MatConvNet team.                                           %
% All rights reserved.                                                                 %
%                                                                                      %
% MatConvNet was originally created by Andrea Vedaldi and Karel Lenc and it is         %
% currently developed by a small community of contributors. It is distributed under    %
% the permissive BSD license.                                                          %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% An Empirical Evaluation of Current Convolutional Architectures’ Ability              %
% to Manage Nuisance Location and Scale Variability.                                   %
% N. Karianakis, J. Dong, and S. Soatto. CVPR 2016.                                    %
%                                                                                      %
% This script reproduces the results in Figure 1.                                      %
% Evaluation of the influence of context (quantified as the rim size around            %
% the ground-truth bounding box) in the classication accuracy.                         %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function info = eval_cnn_imagenet_gt_ds(varargin)
% Evaluate MatConvNet models on ImageNet

tStart = tic;
run('/local2/home/nikos/matconvnet-1.0-beta18/matlab/vl_setupnn.m');
addpath('/local2/home/nikos/matconvnet-1.0-beta18/examples/imagenet/');

% -------------------------------------------------------------------------
%                                                    Network initialization
% -------------------------------------------------------------------------

%modelPath = '/home_server/nick/cnn_models/imagenet-caffe-ref.mat';
modelPath = '/home_server/nick/cnn_models/imagenet-matconvnet-vgg-verydeep-16.mat';

gpuDevice(1);         % select GPU device
net = load(modelPath);
net = vl_simplenn_move(net, 'gpu');

%averageImage = net.meta.normalization.averageImage;                    % average image for imagenet-caffe-ref.mat
averageImage = reshape(net.meta.normalization.averageImage, 1,1,3);     % average image for imagenet-matconvnet-vgg-verydeep-16.mat

net_input_size = net.meta.normalization.imageSize(1);

% -------------------------------------------------------------------------
%                                                      Testing & evaluation
% -------------------------------------------------------------------------

dataDir = '/local/data/Imagenet-2014/cls-loc/val/';
val_images = dir(dataDir);
n_val_images = 50000;

bb_path = '/local/data/Imagenet-2014/cls-loc/bbox/val/';
bbs = dir(bb_path);

bl_fileID = fopen('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/ILSVRC2014_clsloc_validation_blacklist.txt');
bl_vector = zeros(1, n_val_images);

tline = fgets(bl_fileID);
while ischar(tline)
    [num] = strread(tline, '%d');
    bl_vector(num) = -1;    % -1 for black-listed images
    tline = fgets(bl_fileID);
end

fclose(bl_fileID);

gt_fileID = fopen('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/ILSVRC2014_clsloc_validation_ground_truth.txt');
meta_info = load('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/meta_clsloc.mat');

batch_size = 200;
im_cell = cell(1, batch_size);
index_cell = cell(1, batch_size);

% The rim as the percentage between the ground-truth bbox and the whole image.
% The rescaling is isotropic wrt the remaining margin to the image boundaries.
rim = [0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];

top1_score = zeros(n_val_images, length(rim));
top5_score = zeros(n_val_images, length(rim));
n_bl = 0;

for i = 1:batch_size:n_val_images
    for j=1:batch_size
        index_cell{j} = strcat(dataDir, val_images((i-1)+j+2).name);
    end
    im_cell = vl_imreadjpeg(index_cell, 'numThreads', 4);   % reading in batches

    for j=1:batch_size
        display(i+j-1);
        if (bl_vector(i+j-1) == 0)
            I = im_cell{j};

            if (ndims(I) == 2)            % fix for grayscale images
                I=reshape([I I I],[size(I) 3]);
            end

            I = single(I);

            bb_fileID = fopen(strcat(bb_path, bbs(i+j+1).name));
            buffer = fscanf(bb_fileID, '%s');

            xmin_gt = str2double(regexpi(buffer, '(?<=<xmin>\s*)\d*', 'match'));
            xmax_gt = str2double(regexpi(buffer, '(?<=<xmax>\s*)\d*', 'match'));
            ymin_gt = str2double(regexpi(buffer, '(?<=<ymin>\s*)\d*', 'match'));
            ymax_gt = str2double(regexpi(buffer, '(?<=<ymax>\s*)\d*', 'match'));

            max_margin_x = max(size(I,2)-xmax_gt, xmin_gt-1);  % calculate max margin for horizontal
            max_margin_y = max(size(I,1)-ymax_gt, ymin_gt-1);  % and vertical axis

            fclose(bb_fileID);

            tline = fgets(gt_fileID);
            num = strread(tline, '%d');
            WID = meta_info.synsets(num).WNID;     % ground-truth word ID

            %% Experiment for Figure 1
			for r = 1:length(rim)
                rim_x = floor(rim(r)*max_margin_x);   % isotropic rescaling
                rim_y = floor(rim(r)*max_margin_y);

                I_crop = I( max(ymin_gt-rim_y,1):min(ymax_gt+rim_y,size(I,1)), ...
                           max(xmin_gt-rim_x,1):min(xmax_gt+rim_x,size(I,2)), :);

	            % First, downsample with the same ratio exactly as much as the whole image is downsampled
				% (this is for fixing the resolution - OPTIONAL, only for analysis)
	            %I_crop = imresize(I_crop, [round((net_input_size/size(I,1))*size(I_crop,1)) ...
	    		%	    round((net_input_size/size(I,2))*size(I_crop,2))]);

                I_crop = imresize(I_crop, [net_input_size net_input_size]);
                I_crop = bsxfun(@minus, I_crop, averageImage);
                I_ = gpuArray(I_crop);
                res = vl_simplenn(net, I_);
                scores = squeeze(gather(res(end).x));
                [bestScore, best] = sort(scores, 'descend');

				% Evaluation
                if (strcmp(WID, net.meta.classes.name{best(1)}))
                    top1_score(i+j-1, r) = 1;
                end
                if (strcmp(WID, net.meta.classes.name{best(1)}) || strcmp(WID, net.meta.classes.name{best(2)}) || strcmp(WID, net.meta.classes.name{best(3)})...
                        || strcmp(WID, net.meta.classes.name{best(4)}) || strcmp(WID, net.meta.classes.name{best(5)}))
                    top5_score(i+j-1, r) = 1;
                end
	        end
        else
            tline = fgets(gt_fileID);    % so that the groundtruth keeps up with the image iteration
            n_bl = n_bl + 1;
            top1_score(i+j-1,:) = -1;
            top5_score(i+j-1,:) = -1;
        end
    end
end

fclose(gt_fileID);

save('/local2/home/nikos/matconvnet-1.0-beta18/examples/imagenet/nuisances/results/vgg16_ds_orbit_top1.mat', 'top1_score');
save('/local2/home/nikos/matconvnet-1.0-beta18/examples/imagenet/nuisances/results/vgg16_ds_orbit_top5.mat', 'top5_score');

tElapsed = toc(tStart)
