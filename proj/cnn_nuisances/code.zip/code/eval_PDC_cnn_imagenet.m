%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% Copyright (c) 2015-2016, Nikolaos Karianakis. University of California, Los Angeles. %
% All rights reserved.                                                                 %
%                                                                                      %
% This is free software: you can redistribute it and/or modify it under the terms      %
% of the GNU General Public License as published by the Free Software Foundation,      %
% either version 3 of the License, or (at your option) any later version.              %
%                                                                                      %
% The software is distributed in the hope that it will be useful, but WITHOUT ANY      %
% WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A      %
% PARTICULAR PURPOSE.  See the GNU General Public License for more details.            %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% This software uses MatConvNet as its building block. The license of the latter       %
% is attached as required.                                                             %
%                                                                                      %
% Copyright (c) 2014-16 The MatConvNet team.                                           %
% All rights reserved.                                                                 %
%                                                                                      %
% MatConvNet was originally created by Andrea Vedaldi and Karel Lenc and it is         %
% currently developed by a small community of contributors. It is distributed under    %
% the permissive BSD license.                                                          %
%                                                                                      %
% This software also uses the Structured Edge Detection Toolbox V3.0                   %
%    Piotr Dollar (pdollar-at-gmail.com)                                               %
% which is published under the MSR-LA Full Rights License.                             %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                      %
% An Empirical Evaluation of Current Convolutional Architectures’ Ability              %
% to Manage Nuisance Location and Scale Variability.                                   %
% N. Karianakis, J. Dong, and S. Soatto. CVPR 2016.                                    %
%                                                                                      %
% We evaluate our algorithm on Imagenet 2014 (classification) validation set.          %
% PDC stands for P(roposals), D(omains) and C(rops).                                   %
% This script supports all (or any subset of) augmentation techniques.                 %
%                                                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function info = eval_PDC_cnn_imagenet(varargin)
% Evaluate MatConvNet models on ImageNet

% dependencies to the Structured Edge Detection Toolbox
addpath('/home_server/nick/region_proposal/dollar_toolbox/edges-master/');
addpath('/home_server/nick/region_proposal/dollar_toolbox/channels/');
addpath('/home_server/nick/region_proposal/dollar_toolbox/matlab/');
addpath('/home_server/nick/region_proposal/dollar_toolbox/detector/');
addpath('/home_server/nick/region_proposal/dollar_toolbox/external/');
addpath('/home_server/nick/region_proposal/dollar_toolbox/images/');

tStart = tic;
run('/local2/home/nikos/matconvnet-1.0-beta18/matlab/vl_setupnn.m');
addpath('/local2/home/nikos/matconvnet-1.0-beta18/examples/imagenet/');

% -------------------------------------------------------------------------
%                                                    Network initialization
% -------------------------------------------------------------------------

modelPath = '/home_server/nick/cnn_models/imagenet-caffe-ref.mat';
%modelPath = '/home_server/nick/cnn_models/imagenet-matconvnet-vgg-verydeep-16.mat';

%gpuDevice(3);         % select GPU device
net = load(modelPath);
net = vl_simplenn_move(net, 'gpu');

averageImage = net.meta.normalization.averageImage;                  % average image for imagenet-caffe-ref.mat
%averageImage = reshape(net.meta.normalization.averageImage, 1,1,3);   % average image for imagenet-matconvnet-vgg-verydeep-16.mat

net_input_size = net.meta.normalization.imageSize(1);

% -------------------------------------------------------------------------
%                                                      Testing & evaluation
% -------------------------------------------------------------------------

dataDir = '/local/data/Imagenet-2014/cls-loc/val/';      % evaluation data
val_images = dir(dataDir);
n_val_images = 50000;

bl_fileID = fopen('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/ILSVRC2014_clsloc_validation_blacklist.txt');
bl_vector = zeros(1, n_val_images);

tline = fgets(bl_fileID);
while ischar(tline)
	[num] = strread(tline, '%d');
	bl_vector(num) = -1;           % set -1 for black-listed images (0 otherwise)
	tline = fgets(bl_fileID);
end

fclose(bl_fileID);

gt_fileID = fopen('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/ILSVRC2014_clsloc_validation_ground_truth.txt');
meta_info = load('/local/data/Imagenet-2014/ILSVRC2014_devkit/data/meta_clsloc.mat');

image_gt_path = '/local/data/Imagenet-2014/cls-loc/bbox/val/';   % gt object location
image_gt = dir(image_gt_path);

% Choose augmentation technique
P_flag = true;       % (P)roposals
D_flag = true;       % (D)omain sizes
C_flag = true;       % (C)rops

if P_flag
	% load pre-trained edge detection model and set opts (see edgesDemo.m)
	temp=load('/home_server/nick/region_proposal/dollar_toolbox/edges-master/models/forest/modelBsds'); model=temp.model;
	model.opts.multiscale=0; model.opts.nThreads=4;
	model.opts.sharpen=0; model.opts.nTreesEval=1;  % for faster execution (default is 2 and 4)

	% set up opts for edgeBoxes (see edgeBoxes.m)
	opts = edgeBoxes;
	opts.alpha = .65;      % step size of sliding window search
	opts.beta  = .75;      % nms threshold for object proposals
	opts.minScore = .005;  % min score of boxes to detect
	opts.maxBoxes = 200;   % max number of boxes to detect

	kept_bbs = 80;
	proposal_pad = 20;
	no_kept_proposals = 6;

	% organizing the GPU workload in mini-batches
	P_pack_size = 20;
	P_im_pack = zeros(net_input_size, net_input_size, 3, P_pack_size, 'single');
end

if D_flag
	flip_dsp=1;            % 1 to use horizontal flipping (0 otherwise)
	domain_size = [0.6, 0.7, 0.8, 0.9, 1.0];

    % organizing the GPU workload in mini-batches
	D_pack_size = 10;
	D_im_pack = zeros(net_input_size, net_input_size, 3, D_pack_size, 'single');
end

if C_flag
	no_scales = 1;      % values: 1 or 3
	no_crops = 10;      % values: 10 or 50

	if (no_crops==10)
		augm_method = 'f5';
	else
		augm_method = 'f25';
	end

    % organizing the GPU workload in mini-batches
	C_pack_size = 10;
	no_C_packs = (no_scales*no_crops)/C_pack_size;
	C_im_pack = zeros(net_input_size, net_input_size, 3, C_pack_size, 'single');
end

batch_size = 100;
renyi_alpha = 0.35;
n_bl = 0;
im_cell = cell(1, batch_size);
index_cell = cell(1, batch_size);

result_path = '/local2/home/nikos/matconvnet-1.0-beta18/examples/imagenet/nuisances/results/alexNet_alg1_fast_weighted_';
top1_score = zeros(n_val_images, 1);
top5_score = zeros(n_val_images, 1);

for i=1:batch_size:n_val_images           % for all batches
	for j=1:batch_size
		index_cell{j} = strcat(dataDir, val_images((i-1)+j+2).name);   % reading in batches
	end

	im_cell = vl_imreadjpeg(index_cell, 'numThreads', 4);                                      % retrieving the batch
	if C_flag       % retrieving all crops for the entire batch
		im_array = cnn_imagenet_get_batch(index_cell, averageImage, net_input_size, augm_method, no_scales);
	end

	for j=1:batch_size                    % for all images within the batch
		display(i+j-1);
		if (bl_vector(i+j-1) == 0)        % check whether this is a blacklisted image
			I = im_cell{j};
			if (ndims(I) == 2)            % fix for grayscale images
				I=reshape([I I I],[size(I) 3]);
			end

			% -------------------------------------------------------------------------
			%% P_scores: posterior scores for proposals (and optionally their horizontal flip)

			if P_flag
				I = I/255;
				bbs = edgeBoxes(I,model,opts);   % proposals with Edge Boxes

				if (size(bbs,1) == 0)
					bbs = [1, 1, size(I,2), size(I,1), 1];
					xmin_obj = bbs(1);
					xmax_obj = bbs(1)+bbs(3)-1;
					ymin_obj = bbs(2);
					ymax_obj = bbs(2)+bbs(4)-1;
				else
					area_bbs = zeros(size(bbs,1),1);
					for k=1:size(bbs,1)
						area_bbs(k) = bbs(k,3)*bbs(k,4);
					end
					[~, index_area] = sort(area_bbs, 'descend');    % a prior for keeping largest Edge Boxes

					max_area_bbs = zeros(min(kept_bbs, size(bbs,1)), size(bbs, 2));
					for k=1:min(kept_bbs, size(bbs,1))
						max_area_bbs(k,:) = bbs(index_area(k),:);
					end

					xmin_obj = max_area_bbs(:,1);
					xmax_obj = max_area_bbs(:,1)+max_area_bbs(:,3)-1;
					ymin_obj = max_area_bbs(:,2);
					ymax_obj = max_area_bbs(:,2)+max_area_bbs(:,4)-1;
					bbs = max_area_bbs;
				end

				I = I*255;
				I = single(I);

				P_scores = [];

				im_obj = zeros(net_input_size, net_input_size, 3, 2*size(bbs,1), 'single');
				for bb=1:size(bbs,1)
					obj_pad = I( max(ymin_obj(bb)-proposal_pad, 1):min(ymax_obj(bb)+proposal_pad, size(I,1)), ...
						max(xmin_obj(bb)-proposal_pad, 1):min(xmax_obj(bb)+proposal_pad, size(I,2)), :);
					obj_pad = imresize(obj_pad, [net_input_size net_input_size]);
					im_obj(:,:,:,2*bb-1) = obj_pad(:,:,:);
					if (flip_dsp==1)
						obj_pad2 = obj_pad(:, fliplr(1:size(obj_pad,2)), :);
						im_obj(:,:,:,2*bb) = obj_pad2(:,:,:);
					end
				end

				im_obj = bsxfun(@minus, im_obj, averageImage);

				no_obj_packs = floor(size(im_obj,4)/P_pack_size);
				for p=1:no_obj_packs
					for m=1:P_pack_size
						P_im_pack(:,:,:,m)=im_obj(:,:,:,P_pack_size*(p-1)+m);
					end
					im_ = gpuArray(P_im_pack);
					res = vl_simplenn(net, im_);
					scores = squeeze(gather(res(end).x));
					P_scores = [P_scores scores];
				end

				rest_objs = size(im_obj,4) - no_obj_packs*P_pack_size;
				if (rest_objs > 0)
					im_rest = zeros(net_input_size, net_input_size, 3, rest_objs, 'single');
					for p=1:rest_objs
						im_rest(:,:,:,p)=im_obj(:,:,:,no_obj_packs*P_pack_size+p);
					end
					im_ = gpuArray(im_rest);
					res = vl_simplenn(net, im_);
					scores = squeeze(gather(res(end).x));
					P_scores = [P_scores scores];
				end

	            %% keep the most interesting proposals per entropy criterion (and optionally weigh them based on inverse Renyi entropy)
    	        entropy_bb = ones(size(bbs,1), 1);
       	     	for k=1:2:size(P_scores,2)-1
                	entropy_bb(floor(k/2+1)) = 0.5*(1/(1-renyi_alpha))*(log2(sum(power(P_scores(:,k),renyi_alpha)))+ ...
                    	log2(sum(power(P_scores(:,k+1),renyi_alpha))));   % Renyi entropy
            	end
				[entropy_bb, super_index] = sort(entropy_bb, 'ascend');

				added_samples = min(no_kept_proposals, size(bbs, 1));
				inverse_entropy_bb = ones(added_samples, 1);
				for k=1:added_samples
					inverse_entropy_bb(k)=1/entropy_bb(k);
				end

				P_scores_kept = [];
				for k=1:added_samples
					% uniform weights
					%P_scores_kept = [P_scores_kept P_scores(:, (2*super_index(k)-1):(2*super_index(k)))];

					% weighted scheme based on inverse entropy (normalized to add up to added_samples)
					P_scores_kept = [P_scores_kept ((added_samples/entropy_bb(k))/sum(inverse_entropy_bb))* ...
					P_scores(:, (2*super_index(k)-1):(2*super_index(k)))];
				end
			end

			% -------------------------------------------------------------------------
			%% D_scores: posterior scores for concentric domains (and optionally their horizontal flip)

			if D_flag
				D_scores = [];

				for si=1:length(domain_size)
					im_new = I( (floor(((1-domain_size(si))/2)*size(I,1))+1) : floor((1-((1-domain_size(si))/2))*size(I,1)), ...
						(floor(((1-domain_size(si))/2)*size(I,2))+1) : floor((1-((1-domain_size(si))/2))*size(I,2)), :);
					im_new = imresize(im_new, [net_input_size net_input_size]);
					D_im_pack(:,:,:,2*si-1) = im_new(:,:,:);
					if (flip_dsp==1)
						im_new2 = im_new(:, fliplr(1:size(im_new,2)), :);
						D_im_pack(:,:,:,2*si) = im_new2(:,:,:);
					end
				end

				D_im_pack = bsxfun(@minus, D_im_pack, averageImage);
				im_ = gpuArray(D_im_pack);
				res = vl_simplenn(net, im_);
				scores = squeeze(gather(res(end).x));
				D_scores = [D_scores scores];

				% weigh the class posteriors of the dsp samples based on the inverse entropy (optional)
				%inverse_entropy_dsp = ones(2*length(domain_size), 1);
				%for k=1:(2*length(domain_size))
				%    inverse_entropy_dsp(k) = 1/((1/(1-renyi_alpha))*log2(sum(power(D_scores(:,k),renyi_alpha))));
				%end
				%for k=1:(2*length(domain_size))
				%    D_scores(:,k) = ((2*length(domain_size)*inverse_entropy_dsp(k))/sum(inverse_entropy_dsp))*D_scores(:, k);
				%end
			end

			% -------------------------------------------------------------------------
			%% C_scores: posterior scores for regular crops

			if C_flag
				C_scores = [];    % here we accumulate the standard crop responses

				for p=1:no_C_packs
					C_im_pack(:,:,:,:) = im_array(:,:,:,(no_scales*no_crops*(j-1)+C_pack_size*(p-1)+1) ...
								:(no_scales*no_crops*(j-1)+C_pack_size*(p-1)+C_pack_size));
					im_ = gpuArray(C_im_pack);
					res = vl_simplenn(net, im_);
					scores = squeeze(gather(res(end).x));
					C_scores = [C_scores scores];
				end

				% weigh the class posteriors of the crops based on the inverse entropy (optional)
				%inverse_entropy_crops = ones(no_crops, 1);
				%for k=1:no_crops
				%    inverse_entropy_crops(k) = 1/((1/(1-renyi_alpha))*log2(sum(power(C_scores(:,k),renyi_alpha))));
				%end
				%for k=1:no_crops
				%    C_scores(:,k) = ((no_crops*inverse_entropy_crops(k))/sum(inverse_entropy_crops))*C_scores(:, k);
				%end
			end

			% -------------------------------------------------------------------------
			%% evaluation

			all_scores = [];
			if P_flag
				all_scores = [all_scores P_scores_kept];
			end
			if D_flag
				all_scores = [all_scores D_scores];
			end
			if C_flag
				all_scores = [all_scores C_scores];
			end

			scores = mean(all_scores,2);
			[~, best] = sort(scores, 'descend');

			tline = fgets(gt_fileID);
			num = strread(tline, '%d');
			WID = meta_info.synsets(num).WNID;

			if (strcmp(WID, net.meta.classes.name{best(1)}))
				top1_score(i+j-1) = 1;
			end
			if (strcmp(WID, net.meta.classes.name{best(1)}) || strcmp(WID, net.meta.classes.name{best(2)}) ...
				|| strcmp(WID, net.meta.classes.name{best(3)}) || strcmp(WID, net.meta.classes.name{best(4)}) ...
				|| strcmp(WID, net.meta.classes.name{best(5)}))
				top5_score(i+j-1) = 1;
			end
		else
			tline = fgets(gt_fileID);    % so that the groundtruth keeps up with the image iteration
			n_bl = n_bl+1;               % increase the counter of blacklisted images
			top1_score(i+j-1) = -1;
			top5_score(i+j-1) = -1;
		end

		% save partial results (optional)
		if (mod(i+j-1, 10000) == 0)
			save(strcat(result_path, 'top1_bl_', num2str(i+j-1), '.mat'), 'top1_score');
			save(strcat(result_path, 'top5_bl_', num2str(i+j-1), '.mat'), 'top5_score');
		end
	end
end

% calculate the top-1 and the top-5 error
top1_error = (1-sum(top1_score == 1)/sum(top1_score ~= -1))*100
top5_error = (1-sum(top5_score == 1)/sum(top5_score ~= -1))*100
tElapsed = toc(tStart)
